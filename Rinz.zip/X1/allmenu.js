const allmenu = (tz, nama, namabot, prefix, day, yy, thisDay, bulan, wib, wita, wit) => { 
	return `❲ *${namabot}* ❳
${tz} *OWNER* : ${nama}
${tz} *BOTNAME* : ${namabot}
${tz} *PREFIX* : *${prefix}* 
${tz} *TGGAL* : ${day}
${tz} *HARI KE* : ${yy}
${tz} *HARI* : ${thisDay}
${tz} *BULAN* : ${bulan}
${tz} *WIB* : ${wib}
${tz} *WITA* : ${wita}
${tz} *WIT* : ${wit}

❲ *RANDOM TEXT* ❳
${tz} *${prefix}brainly* <text>
${tz} *${prefix}brainly2* <reply.img>
${tz} *${prefix}toimg* <reply.img> 
${tz} *${prefix}tomp3* <reply.vid>
${tz} *${prefix}sticker* <reply.img>
${tz} *${prefix}shopee* <text>
${tz} *${prefix}youwatch* <text>
${tz} *${prefix}artinama* <text>
${tz} *${prefix}artimimpi* <text> 
${tz} *${prefix}attp* <text> 
${tz} *${prefix}foliokanan* <text> 
${tz} *${prefix}foliokiri* <text> 
${tz} *${prefix}nuliskanan* <text> 
${tz} *${prefix}nuliskiri* <text>  

❲ *GROUPMENU* ❳
${tz} *${prefix}antilink* <on/off>
${tz} *${prefix}antivirtext* <on/off>
${tz} *${prefix}delete* <reply.txt>
${tz} *${prefix}hidetag* <text>
${tz} *${prefix}tagall* <text>
${tz} *${prefix}linkgc* 
${tz} *${prefix}listadmin*
${tz} *${prefix}setdesc* <text>
${tz} *${prefix}group* <buka/tutup>
${tz} *${prefix}setname* <text>
${tz} *${prefix}listonline*
${tz} *${prefix}add* <62xxx>
${tz} *${prefix}kick* <@tag/reply>

❲ *OWNERMENU* ❳
${tz} *${prefix}return* <kode>
${tz} *${prefix}setppbot* <reply.img>
${tz} *${prefix}join* <link>
${tz} *${prefix}settz* <kode>
${tz} *${prefix}setprefix* <text>
${tz} *${prefix}bcgc* <text>
${tz} *${prefix}bc* <text>

❲ *SEARCH* ❳
${tz} *${prefix}growstock* <text>
${tz} *${prefix}moddroid* <text>
${tz} *${prefix}kodepos* <text>
${tz} *${prefix}artikata* <text>
${tz} *${prefix}katabijak* <text>
${tz} *${prefix}grubwa* <text>
${tz} *${prefix}stalkyt* <text>
${tz} *${prefix}stalktt* <text>
${tz} *${prefix}pinterest* <text>

❲ *RANDOMANIME* ❳
${tz} *${prefix}topmanga*
${tz} *${prefix}topanime* 
${tz} *${prefix}samehadaku* <text>
${tz} *${prefix}manga* 
${tz} *${prefix}smanga* <text>
${tz} *${prefix}konachan* <text>
${tz} *${prefix}neonime* 
${tz} *${prefix}malanime* 
${tz} *${prefix}anoboy* 

❲ *IMAGEANIME* ❳
${tz} *${prefix}saitama*
${tz} *${prefix}gon*
${tz} *${prefix}killua*
${tz} *${prefix}kakashi*
${tz} *${prefix}tsunade*
${tz} *${prefix}orochimaru*
${tz} *${prefix}mitsuki*
${tz} *${prefix}sarada*
${tz} *${prefix}boruto*
${tz} *${prefix}sakura*
${tz} *${prefix}sasuke*
${tz} *${prefix}minato*
${tz} *${prefix}naruto*
${tz} *${prefix}copper*
${tz} *${prefix}nami*
${tz} *${prefix}ussop*
${tz} *${prefix}sanji*
${tz} *${prefix}luffy*
${tz} *${prefix}zoro*
${tz} *${prefix}senku*
${tz} *${prefix}nezuko*
${tz} *${prefix}tanjirou*
${tz} *${prefix}natsu*
${tz} *${prefix}sagiri*
${tz} *${prefix}rimuru*

❲ *RANDOMMENU* ❳
${tz} *${prefix}motivasi*
${tz} *${prefix}fakta*
${tz} *${prefix}bucin*
${tz} *${prefix}pantun*
${tz} *${prefix}darkjokes*
${tz} *${prefix}loli*
${tz} *${prefix}waifu*
${tz} *${prefix}husbu*
${tz} *${prefix}shota*
${tz} *${prefix}neko*
${tz} *${prefix}kemono*
${tz} *${prefix}wallanime*

❲ *NSFW* ❳
${tz} *${prefix}neko-nsfw*
${tz} *${prefix}blowjob-nsfw*
${tz} *${prefix}kemonomimi-nsfw*
${tz} *${prefix}kitsune-nsfw*
${tz} *${prefix}yuri-nsfw*
${tz} *${prefix}boobs-nsfw*
${tz} *${prefix}kuni-nsfw*

❲ *AUDIO #1* ❳
${tz} *${prefix}audio1*
${tz} *${prefix}audio2*
${tz} *${prefix}audio3*
${tz} *${prefix}audio4*
${tz} *${prefix}audio5*
${tz} *${prefix}audio6*
${tz} *${prefix}audio7*
${tz} *${prefix}audio8*
${tz} *${prefix}audio9*
${tz} *${prefix}audio10*
${tz} *${prefix}audio11*
${tz} *${prefix}audio12*
${tz} *${prefix}audio13*
${tz} *${prefix}audio14*
${tz} *${prefix}audio15*
${tz} *${prefix}audio16*
${tz} *${prefix}audio17*
${tz} *${prefix}audio18*
${tz} *${prefix}audio19*

❲ *AUDIO #2* ❳
${tz} *${prefix}audio20* 
${tz} *${prefix}audio21*
${tz} *${prefix}audio22*
${tz} *${prefix}audio23*
${tz} *${prefix}audio24*
${tz} *${prefix}audio25*
${tz} *${prefix}audio26*
${tz} *${prefix}audio27*
${tz} *${prefix}audio28*
${tz} *${prefix}audio29*
${tz} *${prefix}audio30*
${tz} *${prefix}audio31*
${tz} *${prefix}audio32*
${tz} *${prefix}audio33*
${tz} *${prefix}audio34*
${tz} *${prefix}audio35*

❲ *VCARDRANDOM* ❳
${tz} *${prefix}vsadboy*
${tz} *${prefix}vpakboy*
${tz} *${prefix}vbaik*
${tz} *${prefix}vjago*
${tz} *${prefix}vjelek*
${tz} *${prefix}vcantik*
${tz} *${prefix}vpinter*
${tz} *${prefix}vbeban*
${tz} *${prefix}vkontol*
${tz} *${prefix}vhebat*
${tz} *${prefix}vwibu*
${tz} *${prefix}vharam*
${tz} *${prefix}vbabi*
${tz} *${prefix}vbego*
${tz} *${prefix}vganteng*
${tz} *${prefix}vanjing*
${tz} *${prefix}vmonyet*
${tz} *${prefix}vsadgirl*
${tz} *${prefix}vpakgirl*
${tz} *${prefix}vjahat*
${tz} *${prefix}vnolep*
${tz} *${prefix}vgoblok*

❲ *STICKTAGRANDOM* ❳
${tz} *${prefix}zsadboy*
${tz} *${prefix}zpakboy*
${tz} *${prefix}zbaik*
${tz} *${prefix}zjago*
${tz} *${prefix}zjelek*
${tz} *${prefix}zcantik*
${tz} *${prefix}zpinter*
${tz} *${prefix}zbeban*
${tz} *${prefix}zkontol*
${tz} *${prefix}zhebat*
${tz} *${prefix}zwibu*
${tz} *${prefix}zharam*
${tz} *${prefix}zbabi*
${tz} *${prefix}zbego*
${tz} *${prefix}zganteng*
${tz} *${prefix}zanjing*
${tz} *${prefix}zmonyet*
${tz} *${prefix}zsadgirl*
${tz} *${prefix}zpakgirl*
${tz} *${prefix}zjahat*
${tz} *${prefix}znolep*
${tz} *${prefix}zgoblok*

❲ *TAGRANDOM* ❳
${tz} *${prefix}sadboy*
${tz} *${prefix}pakboy*
${tz} *${prefix}baik*
${tz} *${prefix}jago*
${tz} *${prefix}jelek*
${tz} *${prefix}cantik*
${tz} *${prefix}pinter*
${tz} *${prefix}beban*
${tz} *${prefix}kontol*
${tz} *${prefix}hebat*
${tz} *${prefix}wibu*
${tz} *${prefix}haram*
${tz} *${prefix}babi*
${tz} *${prefix}bego*
${tz} *${prefix}ganteng*
${tz} *${prefix}anjing*
${tz} *${prefix}monyet*
${tz} *${prefix}sadgirl*
${tz} *${prefix}pakgirl*
${tz} *${prefix}jahat*
${tz} *${prefix}nolep*
${tz} *${prefix}goblok*

❲ *RATERANDOM* ❳
${tz} *${prefix}bapercek*
${tz} *${prefix}sangecek*
${tz} *${prefix}pakgirlcek*
${tz} *${prefix}pakboycek*
${tz} *${prefix}kontolcek*
${tz} *${prefix}haramcek*
${tz} *${prefix}anjingcek*
${tz} *${prefix}jahatcek*
${tz} *${prefix}baikcek*
${tz} *${prefix}bebancek*
${tz} *${prefix}babicek*
${tz} *${prefix}nolepcek*
${tz} *${prefix}jagocek*
${tz} *${prefix}pintarcek*
${tz} *${prefix}begocek*
${tz} *${prefix}goblokcek*
${tz} *${prefix}jelekcek*
${tz} *${prefix}cantikcek*
${tz} *${prefix}gantengcek*

❲ *TEXTPRO #1* ❳
${tz} *${prefix}glossy-blue* <text>
${tz} *${prefix}deluxe-gold* <text>
${tz} *${prefix}glossy-carbon* <text>
${tz} *${prefix}xmas* <text>
${tz} *${prefix}blood* <text>
${tz} *${prefix}halloween* <text>
${tz} *${prefix}matrix* <text>
${tz} *${prefix}christmas* <text>
${tz} *${prefix}winter* <text>
${tz} *${prefix}sky* <text>
${tz} *${prefix}luxury* <text>
${tz} *${prefix}gradient* <text>
${tz} *${prefix}vintage* <text>
${tz} *${prefix}beach* <text>
${tz} *${prefix}sand-writing* <text>
${tz} *${prefix}sand-engraved* <text>
${tz} *${prefix}glue-text* <text>
${tz} *${prefix}summery-sand* <text>

❲ *TEXTPRO #2* ❳
${tz} *${prefix}blackpink* <text>
${tz} *${prefix}joker* <text>
${tz} *${prefix}wicker* <text>
${tz} *${prefix}leaves* <text>
${tz} *${prefix}firework* <text>
${tz} *${prefix}lava* <text>
${tz} *${prefix}skeleton* <text>
${tz} *${prefix}toxic* <text>
${tz} *${prefix}thunder* <text>
${tz} *${prefix}horror* <text>
${tz} *${prefix}dropwater* <text>
${tz} *${prefix}break-wall* <text>
${tz} *${prefix}metal-dark* <text>
${tz} *${prefix}neon-light* <text>
${tz} *${prefix}minion-text* <text>
${tz} *${prefix}1917-style* <text>
${tz} *${prefix}holographic-3d* <text>
${tz} *${prefix}metal-purple* <text>
${tz} *${prefix}deluxe-silver* <text>

❲ *TAGRANDOM* ❳
${tz} *${prefix}xsadboy* <@tag>
${tz} *${prefix}xpakboy* <@tag>
${tz} *${prefix}xbaik* <@tag>
${tz} *${prefix}xjago* <@tag>
${tz} *${prefix}xjelek* <@tag>
${tz} *${prefix}xcantik* <@tag>
${tz} *${prefix}xpinter* <@tag>
${tz} *${prefix}xbeban* <@tag>
${tz} *${prefix}xkontol* <@tag>
${tz} *${prefix}xhebat* <@tag>
${tz} *${prefix}xwibu* <@tag>
${tz} *${prefix}xharam* <@tag>
${tz} *${prefix}xbabi* <@tag>
${tz} *${prefix}xbego* <@tag>
${tz} *${prefix}xganteng* <@tag>
${tz} *${prefix}xanjing* <@tag>
${tz} *${prefix}xmonyet* <@tag>
${tz} *${prefix}xsadgirl* <@tag>
${tz} *${prefix}xpakgirl* <@tag>
${tz} *${prefix}xjahat* <@tag>
${tz} *${prefix}xnolep* <@tag>
${tz} *${prefix}xgoblok* <@tag>

❲ *GAMEMENU* ❳
${tz} *${prefix}susunkata*
${tz} *${prefix}tebakkalimat*
${tz} *${prefix}tebakkata*
${tz} *${prefix}tebakkimia*
${tz} *${prefix}tebaklirik*
${tz} *${prefix}tebaktebakan*
${tz} *${prefix}asahotak*
${tz} *${prefix}caklontong*
${tz} *${prefix}siapaaku*

❲ *ASUPAN* ❳
${tz} *${prefix}asupantiktok*
${tz} *${prefix}asupancecan*
${tz} *${prefix}asupanhijab*
${tz} *${prefix}asupansantuy*
${tz} *${prefix}asupanukty*
${tz} *${prefix}asupanrika*
${tz} *${prefix}asupanghea*
${tz} *${prefix}asupanbocil*

❲ *INFO LAIN* ❳
${tz} Jika bot tidak merespon, mungkin bot sedang off
${tz} bot tidak menyimpan riwayat foto/media
${tz} Silahkan beri waktu 5 detik penggunaan per fitur agar tidak menyebabkan spam
${tz} Jika menemukan bug/err silahkan hubungi owner
`
}
exports.allmenu = allmenu