const sticktagrandom = (tz, nama, namabot, prefix, day, yy, thisDay, bulan, wib, wita, wit) => { 
	return `❲ *${namabot}* ❳
${tz} *OWNER* : ${nama}
${tz} *BOTNAME* : ${namabot}
${tz} *PREFIX* : *${prefix}* 
${tz} *TGGAL* : ${day}
${tz} *HARI KE* : ${yy}
${tz} *HARI* : ${thisDay}
${tz} *BULAN* : ${bulan}
${tz} *WIB* : ${wib}
${tz} *WITA* : ${wita}
${tz} *WIT* : ${wit}

❲ *STICKTAGRANDOM* ❳
${tz} *${prefix}zsadboy*
${tz} *${prefix}zpakboy*
${tz} *${prefix}zbaik*
${tz} *${prefix}zjago*
${tz} *${prefix}zjelek*
${tz} *${prefix}zcantik*
${tz} *${prefix}zpinter*
${tz} *${prefix}zbeban*
${tz} *${prefix}zkontol*
${tz} *${prefix}zhebat*
${tz} *${prefix}zwibu*
${tz} *${prefix}zharam*
${tz} *${prefix}zbabi*
${tz} *${prefix}zbego*
${tz} *${prefix}zganteng*
${tz} *${prefix}zanjing*
${tz} *${prefix}zmonyet*
${tz} *${prefix}zsadgirl*
${tz} *${prefix}zpakgirl*
${tz} *${prefix}zjahat*
${tz} *${prefix}znolep*
${tz} *${prefix}zgoblok*

❲ *INFO LAIN* ❳
${tz} Jika bot tidak merespon, mungkin bot sedang off
${tz} bot tidak menyimpan riwayat foto/media
${tz} Silahkan beri waktu 5 detik penggunaan per fitur agar tidak menyebabkan spam
${tz} Jika menemukan bug/err silahkan hubungi owner
`
}
exports.sticktagrandom = sticktagrandom